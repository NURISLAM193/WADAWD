<?php

namespace App\Http\Controllers;

use App\Models\Country;
use Illuminate\Http\Request;

class CountryController extends Controller
{
    public function index()
    {
        return response()->json(Country::with('cities')->get());
    }

    public function store(Request $request)
    {

    }

    public function show(Country $country)
    {
        return response()->json($country->load('cities'));
    }

    public function update(Request $request, Country $country)
    {

    }

    public function destroy(Country $country)
    {
        $country->delete();

        return response()->json(['message' => 'Страна удалена']);
    }
}
