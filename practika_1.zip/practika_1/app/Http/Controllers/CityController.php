<?php

namespace App\Http\Controllers;

use App\Models\City;
use Illuminate\Http\Request;

class CityController extends Controller
{
    public function index()
    {
        return response()->json(City::with('country')->get());
    }

    public function store(Request $request)
    {

    }

    public function show(City $city)
    {
        return response()->json($city->load(['country', 'houses']));
    }

    public function update(Request $request, City $city)
    {

    }

    public function destroy(City $city)
    {
        $city->delete();

        return response()->json(['message' => 'Город удалён']);
    }
}
