<?php

namespace App\Http\Controllers;

use App\Models\Option;
use Illuminate\Http\Request;

class OptionController extends Controller
{
    public function index()
    {
        return response()->json(Option::all());
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required','string','max:255',
            'price' => 'required','numeric','min:0',
            'service_type' => 'required','in:once,per_day,per_day_per_guest',
        ]);

        $option = Option::create($validated);

        return response()->json($option, 201);
    }

    public function show(Option $option)
    {
        return response()->json($option);
    }

    public function update(Request $request, Option $option)
    {
        $validated = $request->validate([
            'name' => 'sometimes','required','string','max:255',
            'price' => 'sometimes','required','numeric','min:0',
            'service_type' => 'sometimes','required','in:once,per_day,per_day_per_guest',
        ]);

        $option->update($validated);

        return response()->json($option);
    }

    public function destroy(Option $option)
    {
        $option->delete();

        return response()->json(['message' => 'Опция удалена']);
    }
}
