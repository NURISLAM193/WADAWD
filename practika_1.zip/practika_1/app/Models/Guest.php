<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Guest extends Model
{
    protected $fillable = [
        'booking_id',
        'last_name',
        'first_name',
        'middle_name',
        'gender',
        'birth_date',
        'phone',
        'document_type',
        'document_number',
    ];

    public function booking(): BelongsTo
    {
        return $this->belongsTo(Booking::class);
    }
}
