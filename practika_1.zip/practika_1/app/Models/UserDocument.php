<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class UserDocument extends Model
{
    protected $fillable = ['user_id', 'document', 'file'];

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }
}
