<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

class Option extends Model
{
    protected $fillable = ['name', 'price', 'service_type'];

    public function houses(): BelongsToMany
    {
        return $this->belongsToMany(House::class, 'house_options');
    }

    public function bookings(): BelongsToMany
    {
        return $this->belongsToMany(Booking::class, 'booking_options');
    }
}
