<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;

class House extends Model
{
    protected $fillable = ['city_id', 'name', 'price', 'description'];

    public function city(): BelongsTo
    {
        return $this->belongsTo(City::class);
    }

    public function photos(): HasMany
    {
        return $this->hasMany(HousePhoto::class);
    }

    public function options(): BelongsToMany
    {
        return $this->belongsToMany(Option::class, 'house_options');
    }

    public function bookings(): HasMany
    {
        return $this->hasMany(Booking::class);
    }
}
