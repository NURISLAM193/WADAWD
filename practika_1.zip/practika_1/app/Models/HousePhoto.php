<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class HousePhoto extends Model
{
    protected $fillable = ['house_id', 'path', 'description'];

    public function house(): BelongsTo
    {
        return $this->belongsTo(House::class);
    }
}
