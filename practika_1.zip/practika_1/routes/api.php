<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HouseController;
use App\Http\Controllers\CountryController;
use App\Http\Controllers\CityController;
use App\Http\Controllers\OptionController;




Route::apiResource('options', OptionController::class);

Route::apiResource('cities', CityController::class);



Route::apiResource('countries', CountryController::class);
Route::apiResource('houses', HouseController::class);

Route::get('/user', function (Request $request) {
    return $request->user();
})->middleware('auth:sanctum');

